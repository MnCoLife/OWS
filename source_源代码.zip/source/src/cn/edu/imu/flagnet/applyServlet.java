/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class applyServlet extends HttpServlet{
private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("bmb_id")==null){
			getServletContext().getRequestDispatcher("/index.jsp").forward(
	                request, response);
		}else{
			String str = "";
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "SELECT question FROM bm_config WHERE bm_column_id = "+request.getParameter("bmb_id")+"");
			try {
				ResultSet ret = pst.executeQuery();
				String questions[] = {};
				while(ret.next()){
					questions = ret.getString("question").split("	");
					for(int i=0;i<questions.length;i++){
						str += "<div class=\"item item-username\"><input id=\"username\" class=\"txt-input txt-username\" type=\"text\" placeholder=\""+questions[i]+"\" value=\"\" name=\"values\"></div>";
					}
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBHelper.close(conn, pst);
			request.setAttribute("msg", str);
			request.setAttribute("bmb_id", request.getParameter("bmb_id"));
			getServletContext().getRequestDispatcher("/apply.jsp").forward(
	                request, response);
		}
	}
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String fee = "";//报名费
		String[] values = request.getParameterValues("values");
		String str = "";
		for(int i=0;i<values.length;i++){
			str += new String(values[i].getBytes("ISO-8859-1"), "utf-8")+"	";
		}
		str = str.substring(0, str.length()-1);
		Connection conn = DBHelper.sql_connection();
		PreparedStatement pst = null;
		pst = DBHelper.pst(conn, "INSERT INTO bm_list VALUES(NULL,\""+str+"\",\"false\",\""+request.getParameter("bmb_id")+"\")");
		try {
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pst = DBHelper.pst(conn, "SELECT fee FROM bm_config WHERE bm_column_id = \""+request.getParameter("bmb_id")+"\"");
		try {
			ResultSet ret = pst.executeQuery();
			ret.next();
			fee = ret.getString("fee");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBHelper.close(conn, pst);
		if(Integer.parseInt(fee)==0){
			request.setAttribute("msg", "<script language='javascript'>alert('报名成功！');window.location.href=\""+(config.app_dir.equals("/")?"/index.jsp":config.app_dir+"/index.jsp")+"\";</script>");
			getServletContext().getRequestDispatcher("/out.jsp").forward(
	                request, response);
		}else{
			String realpath = Thread.currentThread().getContextClassLoader().getResource("").toString()  
					 .replace("/", System.getProperty("file.separator"))
				   	 .replace("file:", "")
				   	 .replace("classes"+System.getProperty("file.separator"), "")
				   	 .substring(1);
			String first[] = QRCodeServlet.decodeImg(new File(realpath+"alipay.jpg")).split("//");
			String second[] = first[1].split("/");
			request.setAttribute("msg", "<script language='javascript'>alert('您需要缴纳"+fee+"元的报名费，将跳转至支付界面，支付完成后请将支付结果出示给工作人员，若未出示证明，工作人员不对产生的一切经济损失负责！');window.location.href=\""+first[0].toLowerCase()+"//"+second[0].toLowerCase()+"/"+second[1]+"\";</script>");
			getServletContext().getRequestDispatcher("/out.jsp").forward(
	                request, response);
		}
		
	}
}
