/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/adminServlet")
public class adminServlet extends HttpServlet{
		
		private static final long serialVersionUID = 1L;
		
		private static String realpath = Thread.currentThread().getContextClassLoader().getResource("").toString()  
				.replace("/", System.getProperty("file.separator"))
			   	 .replace("file:", "")
			   	 .replace("classes"+System.getProperty("file.separator"), "")
			   	 .substring(1);
		
		private final static String realpath_addColumn_lock = (File.separator.equals("/")?"/":"") + realpath + "addColumn.lock";
		private final static String realpath_addTopic_lock = (File.separator.equals("/")?"/":"") + realpath + "addTopic.lock";
		private final static String realpath_addTyper_lock = (File.separator.equals("/")?"/":"") + realpath + "addTyper.lock";
		
		protected void doGet(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
			if(request.getParameter("code")==null||!config.adminCode.containsKey(request.getParameter("code"))){
				if(config.qrLoginCode.containsKey(request.getParameter("code"))){
					config.qrLoginCode.remove(request.getParameter("code"));
				}
				PassWordCreate pWordCreate = new PassWordCreate();
		    	String pwd = pWordCreate.createPassWord(64);
		    	request.setAttribute("code", pwd);
					getServletContext().getRequestDispatcher("/admin/qrlogin.jsp").forward(
			                request, response);
			}else{
				if(!config.adminId.containsKey(request.getParameter("code"))){
					if(request.getParameter("action")!=null){
						switch(Integer.parseInt(request.getParameter("action"))){
							case 17:{
								if(config.qrLoginCode.containsKey(request.getParameter("code"))){
									config.qrLoginCode.remove(request.getParameter("code"));
								}
								config.qrLoginCode.put(request.getParameter("code"), "saomiaochenggong");
								request.setAttribute("code",request.getParameter("code"));
								getServletContext().getRequestDispatcher("/admin/qrScan.jsp").forward(
						                request, response);
							}break;//收集二维码登录信息
							default:{
								PassWordCreate pWordCreate = new PassWordCreate();
						    	String pwd = pWordCreate.createPassWord(64);
						    	request.setAttribute("code", pwd);
									getServletContext().getRequestDispatcher("/admin/qrlogin.jsp").forward(
							                request, response);
							}break;//二维码登录
						}
					}else{
						PassWordCreate pWordCreate = new PassWordCreate();
				    	String pwd = pWordCreate.createPassWord(64);
				    	request.setAttribute("code", pwd);
							getServletContext().getRequestDispatcher("/admin/qrlogin.jsp").forward(
					                request, response);
					}//二维码登录
				}else{
					if(request.getParameter("action")==null){
						request.setAttribute("code",request.getParameter("code"));
						getServletContext().getRequestDispatcher("/admin/index.jsp").forward(
				                request, response);
					}else{
						int actionCode = Integer.parseInt(request.getParameter("action"));
						switch(actionCode){
							case 0:{
								request.setAttribute("code",request.getParameter("code"));
								request.setAttribute("result",getAllArticles(request.getParameter("code"), config.app_dir));
								getServletContext().getRequestDispatcher("/admin/wenzhang.jsp").forward(
						                request, response);
							}break;//全部文章
							case 1:{
									if(request.getParameter("keyWord")==null){
										request.setAttribute("code",request.getParameter("code"));
										getServletContext().getRequestDispatcher("/admin/search_wenzhang.jsp").forward(
								                request, response);
									}else{
										request.setAttribute("code",request.getParameter("code"));
										request.setAttribute("result",getArticlesByKeyword(new String(request.getParameter("keyWord").getBytes("ISO-8859-1"),"utf-8"), request.getParameter("code"),config.app_dir));
										getServletContext().getRequestDispatcher("/admin/search_wenzhang.jsp").forward(
								                request, response);
									}
								}
							break;//搜索文章
							case 2:{
									boolean ret = jiechusuoding(realpath_addTopic_lock);
									if(ret){
										getServletContext().getRequestDispatcher("/admin/result.jsp").forward(
								                request, response);
									}else{
										request.setAttribute("error","操作失败");
										getServletContext().getRequestDispatcher("/error.jsp").forward(
								                request, response);
									}
								}//解除专题锁定
							break;
							case 3:{
								request.setAttribute("name","专题名称");
								request.setAttribute("type","专题");
								request.setAttribute("add", "<a href=\""+(config.app_dir.equals("/")?"":config.app_dir)+"/addTopic.jsp\">添加专题</a>");
								request.setAttribute("width","33%");
								request.setAttribute("export","");
								request.setAttribute("result",getAllTopic(request.getParameter("code"), config.app_dir));
								getServletContext().getRequestDispatcher("/admin/typeManage.jsp").forward(
						                request, response);
							}break;//专题列表页
							case 4:{
									boolean ret = jiechusuoding(realpath_addColumn_lock);
									if(ret){
										getServletContext().getRequestDispatcher("/admin/result.jsp").forward(
								                request, response);
									}else{
										request.setAttribute("error","操作失败");
										getServletContext().getRequestDispatcher("/error.jsp").forward(
								                request, response);
									}
								}
							break;//解除栏目锁定
							case 5:{
								request.setAttribute("name","栏目名称");
								request.setAttribute("type","栏目");
								request.setAttribute("add", "<a href=\""+(config.app_dir.equals("/")?"":config.app_dir)+"/addColumn.jsp\">添加栏目</a>");
								request.setAttribute("width","33%");
								request.setAttribute("export","");
								request.setAttribute("result",getAllColumn(request.getParameter("code"), config.app_dir));
								getServletContext().getRequestDispatcher("/admin/typeManage.jsp").forward(
						                request, response);
							}break;//栏目列表页
							case 6:{
								if(config.adminId.get(request.getParameter("code")).equals("1")){
										boolean ret = jiechusuoding(realpath_addTyper_lock);
										if(ret){
											getServletContext().getRequestDispatcher("/admin/result.jsp").forward(
									                request, response);
										}else{
											request.setAttribute("error","操作失败");
											getServletContext().getRequestDispatcher("/error.jsp").forward(
									                request, response);
										}
								}else{
									request.setAttribute("error","您没有操作权限");
									getServletContext().getRequestDispatcher("/error.jsp").forward(
							                request, response);
								}
							}
							break;//解除员工锁定
							case 7:{
								request.setAttribute("name","员工名称");
								request.setAttribute("type","员工");
								request.setAttribute("add", "<a href=\""+(config.app_dir.equals("/")?"":config.app_dir)+"/addTyper.jsp\">添加员工</a>");
								request.setAttribute("width","25%");
								request.setAttribute("export","<th>生成发布器</th>");
								request.setAttribute("result",getAllTyper(request.getParameter("code"), config.app_dir));
								getServletContext().getRequestDispatcher("/admin/typeManage.jsp").forward(
						                request, response);
							}break;//员工列表页
							case 8:{
								boolean ret = delArticle(request.getParameter("article_id"),(File.separator.equals("/")?"/":"") + getServletContext().getRealPath("./") + File.separator + config.UPLOAD_DIRECTORY + File.separator);
								if(ret){
									request.setAttribute("msg", "<script language='javascript'>alert('操作成功！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}else{
									request.setAttribute("msg", "<script language='javascript'>alert('操作失败！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}
							}break;//删除文章
							case 9:{
								boolean ret = delTopic(request.getParameter("topic_id"));
								if(ret){
									request.setAttribute("msg", "<script language='javascript'>alert('操作成功！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}else{
									request.setAttribute("msg", "<script language='javascript'>alert('操作失败！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}
							}break;//删除专题
							case 10:{
								boolean ret = delColumn(request.getParameter("column_id"));
								if(ret){
									request.setAttribute("msg", "<script language='javascript'>alert('操作成功！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}else{
									request.setAttribute("msg", "<script language='javascript'>alert('操作失败！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}
							}break;//删除栏目
							case 11:{
								boolean ret = delTyper(request.getParameter("id"));
								if(ret){
									request.setAttribute("msg", "<script language='javascript'>alert('操作成功！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}else{
									request.setAttribute("msg", "<script language='javascript'>alert('操作失败！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}
							}break;//删除员工
							case 12:{
								request.setAttribute("name",config.adminCode.get(request.getParameter("code")));
								getServletContext().getRequestDispatcher("/admin/main.jsp").forward(
						                request, response);
							}break;//加载主页
							case 13:{
								logout(request.getParameter("code"));
								getServletContext().getRequestDispatcher("/admin.html").forward(
						                request, response);
							}
							break;//退出登录
							case 14:{
								boolean ret = suoding(realpath_addTopic_lock);
								if(ret){
									getServletContext().getRequestDispatcher("/admin/result.jsp").forward(
							                request, response);
								}
							}
							break;//锁定专题
							case 15:{
								boolean ret = suoding(realpath_addColumn_lock);
								if(ret){
									getServletContext().getRequestDispatcher("/admin/result.jsp").forward(
							                request, response);
								}
							}
							break;//锁定栏目
							case 16:{
								if(config.adminId.get(request.getParameter("code")).equals("1")){
									boolean ret = suoding(realpath_addTyper_lock);
									if(ret){
										getServletContext().getRequestDispatcher("/admin/result.jsp").forward(
								                request, response);
									}
								}else{
									request.setAttribute("error","您没有操作权限");
									getServletContext().getRequestDispatcher("/error.jsp").forward(
							                request, response);
								}
								
							}
							break;//锁定员工
							case 18:{
								if(config.adminId.get(request.getParameter("code")).equals("1")){
									boolean ret = qingchuhuancun();
									if(ret){
										getServletContext().getRequestDispatcher("/admin/result.jsp").forward(
								                request, response);
									}
								}else{
									request.setAttribute("error","您没有操作权限");
									getServletContext().getRequestDispatcher("/error.jsp").forward(
							                request, response);
								}
								
							}
							break;//清除缓存
							case 19:{
								request.setAttribute("code", request.getParameter("code"));
								getServletContext().getRequestDispatcher("/addBmb.jsp").forward(
						                request, response);
							}break;//跳转至添加报名表
							case 20:{
								request.setAttribute("name","表单内容");
								request.setAttribute("type","表单");
								request.setAttribute("add", "报名表");
								request.setAttribute("width","14%");
								request.setAttribute("export","<th>报名费</th><th>生成报名链接</th><th>生成审核链接</th><th>管理</th>");
								request.setAttribute("result",getQuestions(request,request.getParameter("code"), config.app_dir));
								getServletContext().getRequestDispatcher("/admin/typeManage.jsp").forward(
						                request, response);
							}break;//获取表单列表
							case 21:{
								boolean succeed = delBmb(request.getParameter("bmb_id"));
								if(succeed){
									request.setAttribute("msg", "<script language='javascript'>alert('操作成功！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}else{
									request.setAttribute("msg", "<script language='javascript'>alert('操作失败！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}
							}break;//删除报名表
							case 22:{
								boolean succeed = updateFee(request.getParameter("bmb_id"), request.getParameter("fee"));
								if(succeed){
									request.setAttribute("msg", "<script language='javascript'>alert('操作成功！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}else{
									request.setAttribute("msg", "<script language='javascript'>alert('操作失败！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}
							}break;//修改报名费
							case 23:{
								request.setAttribute("export","<a href=\""+(config.app_dir.equals("/")?"":config.app_dir)+"/exportXLS?code="+request.getParameter("code")+"&bmb_id="+request.getParameter("bmb_id")+"\">导出汇总表</a>/<a href=\""+(config.app_dir.equals("/")?"":config.app_dir)+"/admin?action=26&code="+request.getParameter("code")+"&bmb_id="+request.getParameter("bmb_id")+"\">清除未缴费报名信息</a>");
								request.setAttribute("result",bm_list(request.getParameter("bmb_id"), config.app_dir, request.getParameter("code")));
								getServletContext().getRequestDispatcher("/admin/bmManage.jsp").forward(
						                request, response);
							}break;//管理报名信息（列表）
							case 24:{
								boolean succeed = delBminfo(request.getParameter("id"));
								if(succeed){
									request.setAttribute("msg", "<script language='javascript'>alert('操作成功！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}else{
									request.setAttribute("msg", "<script language='javascript'>alert('操作失败！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}
							}break;//删除报名信息
							case 25:{
								boolean succeed = updateFeeState(request.getParameter("id"), request.getParameter("toState"));
								if(succeed){
									request.setAttribute("msg", "<script language='javascript'>alert('操作成功！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}else{
									request.setAttribute("msg", "<script language='javascript'>alert('操作失败！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}
							}break;//修改缴费状态
							case 26:{
								boolean succeed = clearIsNotFeeBminfo(request.getParameter("bmb_id"));
								if(succeed){
									request.setAttribute("msg", "<script language='javascript'>alert('操作成功！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}else{
									request.setAttribute("msg", "<script language='javascript'>alert('操作失败！');window.location.href = document.referrer;</script>");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
								}
							}break;//删除未缴费报名信息
							case 27:{
								request.setAttribute("name", config.adminCode.get(request.getParameter("code")));
								request.setAttribute("org", config.organize_name);
								request.setAttribute("copy", config.copyright);
								request.setAttribute("isShowCopy", (config.isShowCopyRight.equals("true")?"是":"否"));
								getServletContext().getRequestDispatcher("/admin/web_information.jsp").forward(
						                request, response);
							}break;//显示网站配置
							case 28:{
								myProcess.myGet(request, response);
							}break;//二次开发接口
							default:{
								getServletContext().getRequestDispatcher("/index.jsp").forward(
						                request, response);
							}
							break;
						}
					}
				}
				
			}
			
		}
		
		protected void doPost(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			if(request.getParameter("code")!=null&&request.getParameter("action")!=null){
				if(request.getParameter("action").equals("3")){
					if(config.qrLoginCode.containsKey(request.getParameter("code"))){
						//System.out.println("qrLoginCode:"+config.qrLoginCode.get(request.getParameter("code")).equals("invalid")+config.qrLoginCode.get(request.getParameter("code")).toString().equals("invalid"));
						boolean invalid = config.qrLoginCode.get(request.getParameter("code")).equals("wuxiao");
						if(invalid){
							request.setAttribute("msg", "{\"state\":\"wuxiao\"}");
							getServletContext().getRequestDispatcher("/out.jsp").forward(
					                request, response);
							return;
						}else{
							boolean succeed = config.qrLoginCode.get(request.getParameter("code")).equals("saomiaochenggong")&&!config.adminId.containsKey(request.getParameter("code"));
							if(succeed){
								request.setAttribute("msg", "{\"state\":\"saomiaochenggong\"}");
								getServletContext().getRequestDispatcher("/out.jsp").forward(
						                request, response);
								return;
							}else{
								if(config.adminId.containsKey(request.getParameter("code"))){
									request.setAttribute("msg", "{\"state\":\"true\"}");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
									return;
								}else{
									request.setAttribute("msg", "{\"state\":\"false\"}");
									getServletContext().getRequestDispatcher("/out.jsp").forward(
							                request, response);
									return;
								}
							}
						}	
					}else{
						request.setAttribute("msg", "{\"state\":\"wuxiao\"}");
						getServletContext().getRequestDispatcher("/out.jsp").forward(
				                request, response);
						return;
					}
				}
			}//二维码登录验证
			if(request.getParameter("action")!=null&&request.getParameter("code")==null){
				if(request.getParameter("action").equals("0")){
					request.setAttribute("msg", login(request.getParameter("md5")));
					getServletContext().getRequestDispatcher("/result.jsp").forward(
			                request, response);
					return;
				}
			}//控制台登录
			
			if(request.getParameter("code")==null||!config.adminCode.containsKey(request.getParameter("code"))){
				request.setAttribute("msg", "信息已过期，请重新扫码登录");
					getServletContext().getRequestDispatcher("/result.jsp").forward(
			                request, response);
			}else{
				if(request.getParameter("action")==null){
					getServletContext().getRequestDispatcher("/index.jsp").forward(
			                request, response);
				}else{
					String action = request.getParameter("action");
					int actionCode = Integer.parseInt(action);
					switch(actionCode){
						case 1: 
							logout(request.getParameter("code"));
						break;//登出
						case 2:{
							if(config.qrLoginCode.containsKey(request.getParameter("code"))){
								request.setAttribute("msg", qr_login(request.getParameter("id"),new String(request.getParameter("name").getBytes("ISO-8859-1"), "utf-8"),request.getParameter("first"),request.getParameter("second"),request.getParameter("third"),request.getParameter("code")));
								getServletContext().getRequestDispatcher("/out.jsp").forward(
						                request, response);
							}else{
								getServletContext().getRequestDispatcher("/admin").forward(
						                request, response);
							}
						}break;//二维码登录
						case 4:{
							boolean succeed = setBmQuestions(request);
							if(succeed){
								getServletContext().getRequestDispatcher("/admin/result.jsp").forward(
						                request, response);
							}else{
								request.setAttribute("msg", "操作失败");
								getServletContext().getRequestDispatcher("/result.jsp").forward(
						                request, response);
							}
						}break;//设置报名问题
						case 5:{
							myProcess.myPost(request, response);
						}break;//二次开发接口
						default:{
							getServletContext().getRequestDispatcher("/index.jsp").forward(
					                request, response);
						}
						break;
					}
				}
			}
		}
		
		private String login(String md5){
			String str_ret = "";
			String[] admin_infos = Des.strDec(md5, config.firstKey, config.secondKey, config.thirdKey).split("	");
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst;
			pst = DBHelper.pst(conn, "SELECT COUNT(*) FROM typer WHERE name = '"+admin_infos[1]+"' and id = "+admin_infos[0]);
			try {
				SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmm");
				String code = df.format(new Date());
				ResultSet ret = pst.executeQuery();
				ret.next();
				if(Integer.parseInt(ret.getString("COUNT(*)"))!=1){
					str_ret = "{\"state\":\"false\",\"reason\":\"noExist\"}";
				}else{
					if(!admin_infos[2].equals(code)){
						str_ret = "{\"state\":\"false\",\"reason\":\"codeException\"}";
					}else{
						PassWordCreate rand =  new PassWordCreate();
						String pwd = rand.createPassWord(64);
						if(config.adminCode.containsKey(pwd)){
							config.adminCode.remove(pwd);
						}
						config.adminCode.put(pwd, admin_infos[1]);
						config.adminId.put(pwd, admin_infos[0]);
						str_ret = "{\"state\":\"true\",\"session\":\""+pwd+"\"}";
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				str_ret = "{\"state\":\"false\",\"reason\":\"sqlerror\"}";
			}
			DBHelper.close(conn, pst);
			return str_ret;
		}
		
		private String qr_login(String id,String name,String first,String second,String third,String pwd){
			String str_ret = "";
			if(!first.equals(config.firstKey)||!second.equals(config.secondKey)||!third.equals(config.thirdKey)){
				config.adminCode.remove(pwd);
				if(config.qrLoginCode.containsKey(pwd)){
					config.qrLoginCode.remove(pwd);
				}
				config.qrLoginCode.put(pwd, "wuxiao");
				str_ret = "<script language='javascript'>alert('登录失败！');window.location.href=\""+(config.app_dir.equals("/")?"/index.jsp":config.app_dir+"/index.jsp")+"\";</script>";
			}else{
				Connection conn = DBHelper.sql_connection();
				PreparedStatement pst;
				pst = DBHelper.pst(conn, "SELECT COUNT(*) FROM typer WHERE name = '"+name+"' and id = "+id);
				try {
					ResultSet ret = pst.executeQuery();
					ret.next();
					if(Integer.parseInt(ret.getString("COUNT(*)"))!=1){
						str_ret = "<script language='javascript'>alert('登录失败！');window.location.href=\""+(config.app_dir.equals("/")?"/index.jsp":config.app_dir+"/index.jsp")+"\";</script>";
						if(config.qrLoginCode.containsKey(pwd)){
							config.qrLoginCode.remove(pwd);
						}
						config.qrLoginCode.put(pwd, "wuxiao");
						config.adminCode.remove(pwd);
					}else{
						config.adminCode.put(pwd, name);
						config.adminId.put(pwd, id);
						str_ret = "<script language='javascript'>alert('登录成功！');window.location.href=\""+(config.app_dir.equals("/")?"/index.jsp":config.app_dir+"/index.jsp")+"\";</script>";
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					config.adminCode.remove(pwd);
					if(config.qrLoginCode.containsKey(pwd)){
						config.qrLoginCode.remove(pwd);
					}
					config.qrLoginCode.put(pwd, "wuxiao");
					str_ret = "<script language='javascript'>alert('服务器故障！');window.location.href=\""+(config.app_dir.equals("/")?"/index.jsp":config.app_dir+"/index.jsp")+"\";</script>";
				}
				DBHelper.close(conn, pst);
			}
			return str_ret;
		}
		
		private void logout(String code){
			if(config.adminCode.containsKey(code)){
				config.adminCode.remove(code);
			}
			if(config.adminId.containsKey(code)){
				config.adminId.remove(code);
			}
			if(config.qrLoginCode.containsKey(code)){
				config.qrLoginCode.remove(code);
			}
		}
		
		private boolean jiechusuoding(String filePath){
			File file = new File(filePath);
			if(file.exists()){
				file.delete();
			}
			file = new File(filePath);
			if(file.exists()){
				return false;
			}else{
				return true;
			}
		}
		
		private boolean suoding(String filePath){
			File file = new File(filePath);
			if(!file.exists()){
				try {
					file.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			file = new File(filePath);
			if(file.exists()){
				return true;
			}else{
				return false;
			}
		}
		
		private static String getArticlesByKeyword(String keyword,String code,String path){
			String out = "";
			if(path.equals("/")){
				path = "";
			}
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "SELECT * FROM article WHERE title LIKE '%"+keyword+"%' OR f_title LIKE '%"+keyword+"%'");
			try {
				ResultSet ret = pst.executeQuery();
				while(ret.next()){
					if(ret.getString("title").length()<=9)
					out += "<tr>"
						+"<td>"+ret.getString("article_id")+"</td>"
						+"<td>"+ret.getString("title")+"</td>"
						+"<td>"+ret.getString("f_title")+"</td>"
						+"<td>"+ret.getString("reporter")+"</td>"
						+"<td>"+ret.getString("typer")+"</td>"
						+"<td>"+ret.getString("topic_id")+"</td>"
						+"<td>"+ret.getString("column_id")+"</td>"
						+"<td>"+ret.getString("time")+"</td>"
						+"<td><a href=\""+path+"/article?article_id="+ret.getString("article_id")+"\">查看</a></td>"
						+"<td><a href=\""+path+"/admin?action=8&code="+code+"&article_id="+ret.getString("article_id")+"\">删除</a></td>"
						+"</tr>";
					else
						out += "<tr>"
								+"<td>"+ret.getString("article_id")+"</td>"
								+"<td>"+ret.getString("title").substring(0, 8)+"……</td>"
								+"<td>"+ret.getString("f_title")+"</td>"
								+"<td>"+ret.getString("reporter")+"</td>"
								+"<td>"+ret.getString("typer")+"</td>"
								+"<td>"+ret.getString("topic_id")+"</td>"
								+"<td>"+ret.getString("column_id")+"</td>"
								+"<td>"+ret.getString("time")+"</td>"
								+"<td><a href=\""+path+"/article?article_id="+ret.getString("article_id")+"\">查看</a></td>"
								+"<td><a href=\""+path+"/admin?action=8&code="+code+"&article_id="+ret.getString("article_id")+"\">删除</a></td>"
								+"</tr>";
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBHelper.close(conn, pst);
			return out;
	 }
	
		private static String getAllArticles(String code,String path){
			String out = "";
			if(path.equals("/")){
				path = "";
			}
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "SELECT * FROM article ORDER BY article_id DESC");
			try {
				ResultSet ret = pst.executeQuery();
				while(ret.next()){
					if(ret.getString("title").length()<=9)
					out += "<tr>"
						+"<td>"+ret.getString("article_id")+"</td>"
						+"<td>"+ret.getString("title")+"</td>"
						+"<td>"+ret.getString("f_title")+"</td>"
						+"<td>"+ret.getString("reporter")+"</td>"
						+"<td>"+ret.getString("typer")+"</td>"
						+"<td>"+ret.getString("topic_id")+"</td>"
						+"<td>"+ret.getString("column_id")+"</td>"
						+"<td>"+ret.getString("time")+"</td>"
						+"<td><a href=\""+path+"/article?article_id="+ret.getString("article_id")+"\">查看</a></td>"
						+"<td><a href=\""+path+"/admin?action=8&code="+code+"&article_id="+ret.getString("article_id")+"\">删除</a></td>"
						+"</tr>";
					else
						out += "<tr>"
								+"<td>"+ret.getString("article_id")+"</td>"
								+"<td>"+ret.getString("title").substring(0, 8)+"……</td>"
								+"<td>"+ret.getString("f_title")+"</td>"
								+"<td>"+ret.getString("reporter")+"</td>"
								+"<td>"+ret.getString("typer")+"</td>"
								+"<td>"+ret.getString("topic_id")+"</td>"
								+"<td>"+ret.getString("column_id")+"</td>"
								+"<td>"+ret.getString("time")+"</td>"
								+"<td><a href=\""+path+"/article?article_id="+ret.getString("article_id")+"\">查看</a></td>"
								+"<td><a href=\""+path+"/admin?action=8&code="+code+"&article_id="+ret.getString("article_id")+"\">删除</a></td>"
								+"</tr>";
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBHelper.close(conn, pst);
			return out;
	 }
		
		private static String getAllColumn(String code,String path){
			String out = "";
			if(path.equals("/")){
				path = "";
			}
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "SELECT * FROM column_id");
			try {
				ResultSet ret = pst.executeQuery();
				while(ret.next()){
					
					out += "<tr>"
						+"<td>"+ret.getString("column_id")+"</td>"
						+"<td>"+ret.getString("name")+"</td>"
						+"<td><a href=\""+path+"/admin?action=10&code="+code+"&column_id="+ret.getString("column_id")+"\">删除</a></td>"
						+"</tr>";
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBHelper.close(conn, pst);
			return out;
	 }
		private static String getAllTopic(String code,String path){
			String out = "";
			if(path.equals("/")){
				path = "";
			}
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "SELECT * FROM topic_id");
			try {
				ResultSet ret = pst.executeQuery();
				while(ret.next()){
					
					out += "<tr>"
						+"<td>"+ret.getString("topic_id")+"</td>"
						+"<td>"+ret.getString("name")+"</td>"
						+"<td><a href=\""+path+"/admin?action=9&code="+code+"&topic_id="+ret.getString("topic_id")+"\">删除</a></td>"
						+"</tr>";
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBHelper.close(conn, pst);
			return out;
	 }
		private static String getAllTyper(String code,String path){
			String out = "";
			if(path.equals("/")){
				path = "";
			}
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "SELECT * FROM typer");
			try {
				ResultSet ret = pst.executeQuery();
				if(config.adminId.get(code).equals("1")){
					while(ret.next()){
						if(ret.getString("id").equals("1")){
							out += "<tr>"
									+"<td>"+ret.getString("id")+"</td>"
									+"<td>"+ret.getString("name")+"</td>"
									+"<td><a href=\""+path+"/createCert?name="+ret.getString("name")+"\">生成发布器</a></td>"
									+"<td>不可操作</td>"
									+"</tr>";
						}else{
							out += "<tr>"
									+"<td>"+ret.getString("id")+"</td>"
									+"<td>"+ret.getString("name")+"</td>"
									+"<td><a href=\""+path+"/createCert?name="+ret.getString("name")+"\">生成发布器</a></td>"
									+"<td><a href=\""+path+"/admin?action=11&code="+code+"&id="+ret.getString("id")+"\">删除</a></td>"
									+"</tr>";
						}
					}
				}else{
					while(ret.next()){
						out += "<tr>"
								+"<td>"+ret.getString("id")+"</td>"
								+"<td>"+ret.getString("name")+"</td>"
								+"<td>无权操作</td>"
								+"<td>无权操作</td>"
								+"</tr>";
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBHelper.close(conn, pst);
			return out;
	 }
		
		private static boolean delArticle(String id,String path){
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "SELECT dir_picture FROM article WHERE article_id = "+id);
			try {
				ResultSet ret = pst.executeQuery();
				ret.next();
				File dir = new File(path+ret.getString("dir_picture"));
				deleteDir(dir);
				System.out.println(dir.getAbsolutePath());
				pst = DBHelper.pst(conn, "DELETE FROM article WHERE article_id = "+id);
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
	 }
		private static boolean delTopic(String id){
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "DELETE FROM topic_id WHERE topic_id = "+id);
			try {
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
	 }
		private static boolean delColumn(String id){
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "DELETE FROM column_id WHERE column_id = "+id);
			try {
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
	 }
		private static boolean delTyper(String id){
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "DELETE FROM typer WHERE id = "+id);
			try {
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
	 }
		
		private static boolean qingchuhuancun(){
			config.qrLoginCode.clear();
			if(config.qrLoginCode.size()==0){
				return true;
			}else{
				return false;
			}
	 }
		private static boolean setBmQuestions(HttpServletRequest request){
			String[] names = request.getParameterValues("column_name");
			String questions = "";
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = null;
			for(int i=0;i<names.length;i++){
				questions += names[i]+"	";
			}
			try {
				questions = new String(questions.getBytes("ISO-8859-1"), "utf-8");
				questions = questions.substring(0, questions.length()-1);
				pst = DBHelper.pst(conn, "INSERT INTO bm_config VALUES(NULL,\""+questions+"\",\"0\")");
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (UnsupportedEncodingException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
	}
		private static String getQuestions(HttpServletRequest request,String code,String path){
			String out = "";
			if(path.equals("/")){
				path = "";
			}
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "SELECT * FROM bm_config");
			try {
				ResultSet ret = pst.executeQuery();
				String questions[] = {};
				String question="";
				String app_dir = config.app_dir.equals("/")?"":config.app_dir;
				String url = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + app_dir + "/apply?bmb_id=";
				String url_1 = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + app_dir + "/";
				SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
				while(ret.next()){
					questions = ret.getString("question").split("	");
					question="";
					for(int i=0;i<questions.length;i++){
						question += "问题"+(i+1)+":"+questions[i]+"\\n";
					}
					out += "<tr>"
						+"<td>"+ret.getString("bm_column_id")+"</td>"
						+"<td><a href=\"javascript:void(0)\" onclick=\"alert('"+question+"')\">"+(ret.getString("question").length()>15?ret.getString("question").substring(0, 15)+"……":ret.getString("question"))+"</a></td>"
						+"<td><form action=\""+path+"/admin\" method=\"get\"><input type=\"hidden\" name=\"code\" value=\""+code+"\"><input type=\"hidden\" name=\"bmb_id\" value=\""+ret.getString("bm_column_id")+"\"><input type=\"hidden\" name=\"action\" value=\"22\"><input type=\"text\" name=\"fee\" value=\""+ret.getString("fee")+"\">元<input type=\"submit\" value=\"修改\"></form></td>"
						+"<td><a href=\"javascript:void(0)\" onclick=\"prompt('请复制下面链接','"+url+ret.getString("bm_column_id")+"')\">生成报名链接</a></td>"
						+"<td><a href=\"javascript:void(0)\" onclick=\"prompt('请复制下面链接','"+url_1+Des.strEnc(ret.getString("bm_column_id")+"	"+df.format(new Date()), config.firstKey, config.secondKey, config.thirdKey)+"')\">生成审核链接</a></td>"
						+"<td><a href=\""+path+"/admin?action=23&code="+code+"&bmb_id="+ret.getString("bm_column_id")+"\">管理</a></td>"
						+"<td><a href=\""+path+"/admin?action=21&code="+code+"&bmb_id="+ret.getString("bm_column_id")+"\">删除</a></td>"
						+"</tr>";
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBHelper.close(conn, pst);
			return out;
	 }
		private static boolean updateFee(String id,String fee){
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "UPDATE bm_config SET fee = \""+fee+"\" WHERE bm_column_id = "+id+"");
			try {
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
			
	 }
		private static boolean delBmb(String id){
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "DELETE FROM bm_config WHERE bm_column_id = "+id+"");
			try {
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
			
	 }
		private static String bm_list(String bmb_id,String path,String code){
			String out = "";
			if(path.equals("/")){
				path = "";
			}
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "SELECT * FROM bm_list WHERE bmb_id = \""+bmb_id+"\"");
			try {
				ResultSet ret = pst.executeQuery();
				String answers[] = {};
				String answer = "";
				while(ret.next()){
					answers = ret.getString("bm_infos").split("	");
					answer = "";
					for(int i=0;i<answers.length;i++){
						answer += "回答"+(i+1)+":"+answers[i]+"\\n";
					}
					out += "<tr>"
							+"<td>"+ret.getString("id")+"</td>"
							+"<td><a href=\"javascript:void(0)\" onclick=\"alert('"+answer+"')\">"+(ret.getString("bm_infos").length()>15?ret.getString("bm_infos").substring(0, 15)+"……":ret.getString("bm_infos"))+"</a></td>"
							+"<td>"+(ret.getString("isFee").equals("true")?"已缴费(<a href=\""+path+"/admin?action=25&toState=false&code="+code+"&id="+ret.getString("id")+"\">改变</a>)":"<font color=\"red\">未缴费</font>(<a href=\""+path+"/admin?action=25&toState=true&code="+code+"&id="+ret.getString("id")+"\">改变</a>)")+"</td>"
							+"<td><a href=\""+path+"/admin?action=24&code="+code+"&id="+ret.getString("id")+"\">删除</a></td>"
							+"</tr>";
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			DBHelper.close(conn, pst);
			return out;
	 }
		private static boolean delBminfo(String id){
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "DELETE FROM bm_list WHERE id = "+id+"");
			try {
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
			
	 }
		public static boolean updateFeeState(String id,String fee){
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "UPDATE bm_list SET isFee = \""+fee+"\" WHERE id = "+id+"");
			try {
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
			
	 }
		private static boolean clearIsNotFeeBminfo(String bmb_id){
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "DELETE FROM bm_list WHERE isFee = \"false\" and bmb_id = \""+bmb_id+"\"");
			try {
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
			
	 }
		private static boolean deleteDir(File dir) {
	        if (dir.isDirectory()) {
	            String[] children = dir.list();
	            //递归删除目录中的子目录下
	            for (int i=0; i<children.length; i++) {
	                boolean success = deleteDir(new File(dir, children[i]));
	                if (!success) {
	                    return false;
	                }
	            }
	        }
	        // 目录此时为空，可以删除
	        return dir.delete();
	    }

}
