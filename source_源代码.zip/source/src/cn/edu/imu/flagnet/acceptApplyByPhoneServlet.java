/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class acceptApplyByPhoneServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("code")==null){
			getServletContext().getRequestDispatcher("/index.jsp").forward(
	                request, response);
		}else{
			SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
			String code = request.getParameter("code").replace("/", "");
			code = Des.strDec(code, config.firstKey, config.secondKey, config.thirdKey);
			String infos[] = code.split("	");
			if(!df.format(new Date()).equals(infos[1])){
				getServletContext().getRequestDispatcher("/index.jsp").forward(
		                request, response);
			}else{
				String str = "";
				String applyInfos[] = {};
				String path = config.app_dir.equals("/")?"":config.app_dir;
				Connection conn = DBHelper.sql_connection();
				PreparedStatement pst = DBHelper.pst(conn, "SELECT * FROM bm_list WHERE isFee = \"false\" AND bmb_id = \""+infos[0]+"\"");
				try {
					String js = "";
					ResultSet ret = pst.executeQuery();
					while(ret.next()){
						js = "alert('";
						applyInfos = ret.getString("bm_infos").split("	");
						for(int i=0;i<applyInfos.length;i++){
							js += "信息"+(i+1)+":"+applyInfos[i]+"\\n";
						}
						js += "');";
						str += "<div class=\"list\" style=\"margin-top:5px;\"><form action=\""+path+"/acceptApplyByPhone\" method=\"post\">"+ret.getString("id")+",<a href=\"javascript:void(0)\" onclick=\""+js+"\">"+(applyInfos[0].length()>5?applyInfos[0].substring(0, 5):applyInfos[0])+"</a>,<input type=\"hidden\" name=\"id\" value=\""+ret.getString("id")+"\"><input type=\"submit\" value=\"通过\"></form></div>";
					}
					DBHelper.close(conn, pst);
					request.setAttribute("result", str);
					getServletContext().getRequestDispatcher("/acceptApplyByPhone.jsp").forward(
			                request, response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					getServletContext().getRequestDispatcher("/index.jsp").forward(
			                request, response);
				}
				
			}
		}
		
	}
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("id")==null){
			getServletContext().getRequestDispatcher("/index.jsp").forward(
	                request, response);
		}else{
			boolean succeed = adminServlet.updateFeeState(request.getParameter("id"), "true");
			if(succeed){
				request.setAttribute("msg", "<script language='javascript'>alert('操作成功！');window.location.href = document.referrer;</script>");
				getServletContext().getRequestDispatcher("/out.jsp").forward(
		                request, response);
			}else{
				request.setAttribute("msg", "<script language='javascript'>alert('操作失败！');window.location.href = document.referrer;</script>");
				getServletContext().getRequestDispatcher("/out.jsp").forward(
		                request, response);
			}
		}
	}
}
