/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 功能：前台显示文章
 * 地址：/article
 * 参数：article_id 文章编号
 */
@WebServlet("/showArticleServlet")
public class showArticleServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		if(request.getParameter("article_id") == null){
			request.setAttribute("error", "<script language='javascript'>alert('亲，不要非法访问本页面呦！');window.history.back();</script>");
			getServletContext().getRequestDispatcher("/error.jsp").forward(
	                request, response);
		}else{
			String article_id = request.getParameter("article_id");
			String template = "";
			
			String content = "";
			HashMap<String,HashMap<String,String>> article = getArticle(article_id);
			
			template = "templates/"+article.get("template").get("value").toString();
			
			HashMap<String,String>content_map = article.get("list_content");
			for(int i=0;i<content_map.size();i++){
				if(content_map.get("value_"+i).startsWith("[IMG_") && content_map.get("value_"+i).endsWith("]")){
					content += "<div class='images'><img alt='chatu' src='upload/"+article.get("dir_picture").get("value")+"/"+content_map.get("value_"+i).replace("[IMG_", "").replace("]", "")+"'/></div>";
				}else{
					content += "&nbsp;&nbsp;&nbsp;&nbsp;"+content_map.get("value_"+i)+"<br>";
				}
			}
			
			request.setAttribute("title",article.get("title").get("value").toString());
			request.setAttribute("f_title",article.get("f_title").get("value").toString());
			request.setAttribute("content",content);
			request.setAttribute("reporter",article.get("reporter").get("value").toString());
			request.setAttribute("typer",article.get("typer").get("value").toString());
			
			String time[] = article.get("time").get("value").toString().split("-");
			
			request.setAttribute("time",time[0]+"年"+time[1]+"月"+time[2]+"日"+"&nbsp;"+time[3]+":"+time[4]);
			
	        getServletContext().getRequestDispatcher("/"+template+".jsp").forward(
	                request, response);
		}
		
	}
	
	/**
	 * 功能：根据文章编号获取文章全部信息
	 * 函数：getArticle(article_id)
	 * 参数：article_id 文章编号
	 * 返回：HashMap<String,HashMap<String,String>> 哈希表
	 */
	public static HashMap<String,HashMap<String,String>> getArticle(String article_id){
		
		HashMap<String,HashMap<String,String>> out = new HashMap<String,HashMap<String,String>>();
		HashMap<String,String> temp;
		String str[] = null;
		
		Connection conn = DBHelper.sql_connection();
		PreparedStatement pst = DBHelper.pst(conn, "select * from article where article_id = "+article_id+"");
		try {
			ResultSet ret = pst.executeQuery();
			while(ret.next()){
				temp = new HashMap<String,String>();
				temp.put("value", ret.getString("article_id"));
				out.put("article_id", temp);
				
				temp = new HashMap<String,String>();
				temp.put("value", ret.getString("column_id"));
				out.put("column_id", temp);
				
				temp = new HashMap<String,String>();
				temp.put("value", ret.getString("topic_id"));
				out.put("topic_id", temp);
				
				temp = new HashMap<String,String>();
				temp.put("value", ret.getString("title"));
				out.put("title", temp);
				
				temp = new HashMap<String,String>();
				temp.put("value", ret.getString("f_title"));
				out.put("f_title", temp);
				
				
			 	temp = new HashMap<String,String>();
				str = ret.getString("list_content").split("	");
				
				for(int i = 0;i<str.length;i++){
					if(!str[i].equals("content_end")){
						temp.put("value_"+i, str[i]);
					}
				}
				
				out.put("list_content", temp);
				
				temp = new HashMap<String,String>();
				temp.put("value", ret.getString("dir_picture"));
				out.put("dir_picture", temp);
				
				temp = new HashMap<String,String>();
				temp.put("value", ret.getString("reporter"));
				out.put("reporter", temp);
				
				temp = new HashMap<String,String>();
				temp.put("value", ret.getString("typer"));
				out.put("typer", temp);
				
				temp = new HashMap<String,String>();
				temp.put("value", ret.getString("time"));
				out.put("time", temp);
				
				temp = new HashMap<String,String>();
				temp.put("value", ret.getString("template"));
				out.put("template", temp);
			}
			ret.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		DBHelper.close(conn, pst);//关闭数据库连接
		
		return out;
		
	}
	
	/**
	 * 功能：根据专题编号和栏目编号获取文章列表
	 * 函数：getArticles(topic_id,column_id)
	 * 参数：topic_id 专题编号
	 * 参数：column_id 栏目编号
	 * 返回：HashMap<String,String> 哈希表
	 */
	public static HashMap<String,String> getArticlesByTopicIdAndColumnId(String topic_id,String column_id){
		
		HashMap<String,String> out = new HashMap<String,String>();
		
		Connection conn = DBHelper.sql_connection();
		PreparedStatement pst = DBHelper.pst(conn, "select * from article where topic_id = "+topic_id+" and column_id = "+column_id+"");
		try {
			ResultSet ret = pst.executeQuery();
			while(ret.next()){
				//此处添加文章信息
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBHelper.close(conn, pst);
		return out;
	}
	
	
	public static String getArticlesByKeyword(String keyword){
			String out = "";
		
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = DBHelper.pst(conn, "select * from article where title like '%"+keyword+"%' or f_title like '%"+keyword+"%'");
			try {
				ResultSet ret = pst.executeQuery();
				while(ret.next()){
					if(ret.getString("title").length()<=9)
					out += "<div class=\"list\"><a href=article?article_id=\""+ret.getString("article_id")+"\">"+ret.getString("title")+"</a></div>";
					else
						out += "<div class=\"list\"><a href=article?article_id=\""+ret.getString("article_id")+"\">"+ret.getString("title").substring(0, 8)+"……</a></div>";
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBHelper.close(conn, pst);
			return out;
	}

}
