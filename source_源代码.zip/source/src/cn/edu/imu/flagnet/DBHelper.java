/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBHelper {
	
	    //连接数据库服务器
	    public static Connection sql_connection(){
	    	try {
				Class.forName(config.name);//指定连接类型  
				Connection conn = DriverManager.getConnection(config.url_mysql, config.user, config.password);//获取连接  
				return conn;
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
	    	
	    }
	    
	    //返回准备执行SQL语句
	    public static PreparedStatement pst(Connection conn,String sql) {  
	        try {  
	        	PreparedStatement ret_pst;
	        	ret_pst = conn.prepareStatement(sql);//准备执行语句 
	        	return ret_pst;
	        } catch (Exception e) {  
	            e.printStackTrace();
	            return null;
	        }  
	    } 
	    
	    
	    public static void close(Connection conn,PreparedStatement pst) {  
	        try {  
	            conn.close();  
	            pst.close();  
	        } catch (SQLException e) {  
	            e.printStackTrace();  
	        }  
	    }  
	    
	    public static Connection sql_connection_install(String url,String user,String pwd){
	    	try {
				Class.forName(config.name);//指定连接类型  
				Connection conn = DriverManager.getConnection(url, user, pwd);//获取连接  
				return conn;
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
	    	
	    }
	}  

