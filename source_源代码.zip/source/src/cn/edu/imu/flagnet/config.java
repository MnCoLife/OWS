/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

public class config {
	public static String url_mysql = "jdbc:mysql://"+getAppProperty("mysql_host")+"/"+getAppProperty("mysql_database")+"?characterEncoding=utf-8";//MySQL服务器地址  
	public static String name = "com.mysql.jdbc.Driver";//数据库驱动名  
	public static String user = getAppProperty("mysql_user");//数据库用户名  
	public static String password = getAppProperty("mysql_password");//数据库密码  
	
    public static String UPLOAD_DIRECTORY = getAppProperty("upload_directory");// 上传文件存储目录
    
    public static String directory = "";// 上传文件存储目录
    
    public static String organize_name = Des.strDec(getAppProperty("organize_name"), "he", "xiao", "qi");//组织名
    public static String app_dir = getAppProperty("app_dir");//程序所在目录
    public static String copyright = Des.strDec(getAppProperty("copyright"), "he", "xiao", "qi");//版权
    public static String isShowCopyRight = getAppProperty("isShowCopyRight");//是否显示版权
    
    public static String firstKey = getAppProperty("firstKey");
    public static String secondKey = getAppProperty("secondKey");
    public static String thirdKey = getAppProperty("thirdKey");
    
    public static HashMap<String, String> adminCode = new HashMap<String, String>();//管理员加密码
    public static HashMap<String, String> adminId = new HashMap<String, String>();//管理员身份
    public static HashMap<String, String> qrLoginCode = new HashMap<String, String>();//扫码登录加密码
    
    public static void reLoad(){
    	url_mysql = "jdbc:mysql://"+getAppProperty("mysql_host")+"/"+getAppProperty("mysql_database")+"?characterEncoding=utf-8";//MySQL服务器地址   
    	user = getAppProperty("mysql_user");//数据库用户名  
    	password = getAppProperty("mysql_password");//数据库密码 
        UPLOAD_DIRECTORY = getAppProperty("upload_directory");// 上传文件存储目录
        organize_name = Des.strDec(getAppProperty("organize_name"), "he", "xiao", "qi");//组织名
        app_dir = getAppProperty("app_dir");//程序所在目录
        copyright = Des.strDec(getAppProperty("copyright"), "he", "xiao", "qi");//版权
        isShowCopyRight = getAppProperty("isShowCopyRight");//是否显示版权
        firstKey = getAppProperty("firstKey");
        secondKey = getAppProperty("secondKey");
        thirdKey = getAppProperty("thirdKey");
    }
    
    private static String getAppProperty(String name){
    	 Properties pro = new Properties();  
    	 String realpath = (File.separator.equals("/")?"/":"") + Thread.currentThread().getContextClassLoader().getResource("").toString() 
    	 .replace("/", System.getProperty("file.separator"))
	   	 .replace("file:", "")
	   	 .replace("classes"+System.getProperty("file.separator"), "")
    	 .substring(1);
    	 realpath += "config.properties";
    	 try{  
	    	 FileInputStream in = new FileInputStream(realpath);  
	    	 pro.load(in);
    	 }  
    	 catch(FileNotFoundException e){  
    		 e.printStackTrace();
    	 }  
    	 catch(IOException e){
    		 e.printStackTrace();
    	 }
    	 return pro.getProperty(name);
    }
}