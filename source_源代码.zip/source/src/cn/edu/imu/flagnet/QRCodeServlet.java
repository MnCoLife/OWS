/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;

import jp.sourceforge.qrcode.QRCodeDecoder;
import jp.sourceforge.qrcode.data.QRCodeImage;  

public class QRCodeServlet extends HttpServlet {  
  
    private static final long serialVersionUID = 1L;  
      
    @Override  
    protected void service(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
    	String pwd = request.getParameter("code");
        String content = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + (config.app_dir.equals("/")?"":config.app_dir) + "/admin?action=17&code="+pwd; 
        config.qrLoginCode.put(pwd, "");
        config.adminCode.put(pwd, "");
        QRCodeHandler encoder = new QRCodeHandler();  
        encoder.encoderQRCoder(content, response);  
    }  
    
    public static String decodeImg(File imgFile){  
        BufferedImage image = null;  
        String content = null;  
        try {  
            image = ImageIO.read(imgFile);  
            QRCodeDecoder decoder = new QRCodeDecoder();  
            content = new String(decoder.decode(new CodeImg(image)),"UTF-8");  
        } catch (Exception e) {  
            System.out.println("二维码解析失败!"+e.getMessage());  
            e.printStackTrace();  
        }  
        return content;  
    }  
}

	final class CodeImg implements QRCodeImage{  
	    private BufferedImage image;  
	    public CodeImg(BufferedImage image) {  
	        super();  
	        this.image = image;  
	    }  
	    @Override  
	    public int getHeight() {  
	        return image.getHeight();  
	    }  
	    @Override  
	    public int getPixel(int x, int y) {  
	        return image.getRGB(x, y);  
	    }  
	    @Override  
	    public int getWidth() {  
	        return image.getWidth();  
	    }  
	    public BufferedImage getImage() {  
	        return image;  
	    }  
	    public void setImage(BufferedImage image) {  
	        this.image = image;  
	    }  
	
	}  