/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class myProcess{

	public static void myGet(HttpServletRequest myRequest,HttpServletResponse myResponse) throws ServletException, IOException{
		
	}
	
	public static void myPost(HttpServletRequest myRequest,HttpServletResponse myResponse) throws ServletException, IOException{
		
	}
}
