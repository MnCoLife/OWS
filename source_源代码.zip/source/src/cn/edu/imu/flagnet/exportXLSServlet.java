/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class exportXLSServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServletException{
		if(request.getParameter("code")==null||request.getParameter("bmb_id")==null){
			getServletContext().getRequestDispatcher("/index.jsp").forward(
	                request, response);
		}else{
			 if(!config.adminId.containsKey(request.getParameter("code"))){
				 getServletContext().getRequestDispatcher("/index.jsp").forward(
			                request, response);
			 }else{
				 String column = "";
				 String contents = "";
				 String infos[] = {};
				 Connection conn = DBHelper.sql_connection();
				 PreparedStatement pst = DBHelper.pst(conn, "SELECT question FROM bm_config WHERE bm_column_id ="+request.getParameter("bmb_id"));
				 ResultSet ret;
				try {
					ret = pst.executeQuery();
					while(ret.next()){
						 column += "报名编号"+",";
						 infos = ret.getString("question").split("	");
						 for(int i=0;i<infos.length;i++){
							 column += infos[i]+",";
						 }
						 column += "缴费状态";
					 }
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				 
				 pst = DBHelper.pst(conn, "SELECT * FROM bm_list WHERE bmb_id = \""+request.getParameter("bmb_id")+"\"");
				 try {
					ret = pst.executeQuery();
					while(ret.next()){
						contents += ret.getString("id")+",";
						 infos = ret.getString("bm_infos").split("	");
						 for(int i=0;i<infos.length;i++){
							 contents += infos[i]+",";
						 }
						 if(ret.getString("isFee").equals("true")){
							 contents += "已缴费";
						 }else{
							 contents += "未缴费";
						 }
						 contents += "\r\n";
					 }
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				 DBHelper.close(conn, pst);
				 
				 String fileName = "汇总表";
				 ByteArrayOutputStream os = new ByteArrayOutputStream();
				 os.write((column+"\r\n"+contents).getBytes());
				 byte[] content = os.toByteArray();
			     InputStream is = new ByteArrayInputStream(content);
			     response.reset();
			     response.setContentType("text/html;charset=utf-8");
			     response.setHeader("Content-Disposition", "attachment;filename=" + new String(fileName.getBytes("gbk"),"ISO-8859-1") + ".csv");
				 ServletOutputStream out = response.getOutputStream();
				 BufferedInputStream bis = null;
				 BufferedOutputStream bos = null;
				 
				 try{
				        bis = new BufferedInputStream(is);
				        bos = new BufferedOutputStream(out);
				        byte[] buff = new byte[2048];
				        int bytesRead;
				        // Simple read/write loop.
				        while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
				          bos.write(buff, 0, bytesRead);
				        }
				  } catch (Exception e) {
				        // TODO: handle exception
				        e.printStackTrace();
				  } finally {
				        if (bis != null)
				          bis.close();
				        if (bos != null)
				          bos.close();
				  }
			 }
		}
		
		 
	}
}
