/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {

		private static final long serialVersionUID = 1L;
	
	 protected void doPost(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
				
		if(request.getParameter("md5")==null){
			request.setAttribute("error", "<script language='javascript'>alert('登录方式错误！');window.history.back();</script>");
			getServletContext().getRequestDispatcher("/error.jsp").forward(
	                request, response);
		}else{
			SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmm");
			if(Des.strDec(request.getParameter("md5"), config.firstKey, config.secondKey, config.thirdKey).equals(df.format(new Date()))){
				request.setAttribute("typer",new String(request.getParameter("name").getBytes("ISO-8859-1"),"utf-8"));
				request.setAttribute("msg", "<script language='javascript'>alert('欢迎您："+Des.strDec(new String(request.getParameter("name").getBytes("ISO-8859-1"),"utf-8"), config.firstKey, config.secondKey, config.thirdKey) +"！');</script>");
				getServletContext().getRequestDispatcher("/upload.jsp").forward(
		                request, response);
			}else{
				request.setAttribute("error", "<script language='javascript'>alert('登录验证信息错误！');window.history.back();</script>");
				getServletContext().getRequestDispatcher("/error.jsp").forward(
		                request, response);
			}
			
		}
		 
		 
	 }
	 
	 protected void doGet(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			getServletContext().getRequestDispatcher("/index.jsp").forward(
	                request, response);
	}
	 
	
}