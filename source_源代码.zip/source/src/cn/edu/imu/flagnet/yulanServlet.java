/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/yulanServlet")
public class yulanServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String[] contents = request.getParameterValues("content");
		
		if((contents+"").equals(null+"")){
			request.setAttribute("error", "<script language='javascript'>alert('亲，还没有添加段落，不能预览的呦！');window.history.back();</script>");
			getServletContext().getRequestDispatcher("/error.jsp").forward(
	                request, response);
		}else{
			String template = "templates/"+request.getParameter("template").toString();
			String content = "";
			
			for(int i=0;i<contents.length;i++){
				if(contents[i].startsWith("[IMG_") && contents[i].endsWith("]")){
					content += "&nbsp;&nbsp;&nbsp;&nbsp;<img alt='chatu' src='upload/"+config.directory+"/"+contents[i].replace("[IMG_", "").replace("]", "")+"'/><br>";
				}else{
					content += "&nbsp;&nbsp;&nbsp;&nbsp;"+contents[i]+"<br>";
				}
			}
			
			SimpleDateFormat df = new SimpleDateFormat("yyyy年MM月dd HH:mm");//设置日期格式
			
			request.setAttribute("title",new String(request.getParameter("title").getBytes("ISO-8859-1"),"utf-8"));
			request.setAttribute("f_title",new String(request.getParameter("f_title").getBytes("ISO-8859-1"),"utf-8"));
			request.setAttribute("content",new String(content.getBytes("ISO-8859-1"),"utf-8"));
			request.setAttribute("reporter",new String(request.getParameter("reporter").getBytes("ISO-8859-1"),"utf-8"));
			request.setAttribute("typer",new String(request.getParameter("typer").getBytes("ISO-8859-1"),"utf-8"));
			request.setAttribute("time",df.format(new Date()));
			
	        getServletContext().getRequestDispatcher("/"+template+".jsp").forward(
	                request, response);
		}
	}
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		getServletContext().getRequestDispatcher("/index.jsp").forward(
                request, response);
	}
}
