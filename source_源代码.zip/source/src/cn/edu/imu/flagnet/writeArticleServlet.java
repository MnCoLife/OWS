/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/writeArticleServlet")
public class writeArticleServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String[] contents = request.getParameterValues("content");
		if((contents+"").equals(null+"")||request.getParameter("typer").equals("")||request.getParameter("typer") == null){
			request.setAttribute("msg","<script language='javascript'>alert('亲，还没有填写完整信息，不能发布的呦！');window.history.back();</script>");
			getServletContext().getRequestDispatcher("/result.jsp").forward(
	                request, response);
		}else{
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");//设置日期格式
			HashMap<String,String> list_content = new HashMap<String,String>();
			for(int i=0;i<contents.length;i++)list_content.put("value_"+i, new String(contents[i].getBytes("ISO-8859-1"),"utf-8"));
			if(uploadArticle(
					request.getParameter("topic"), 
					request.getParameter("column"),
					new String(request.getParameter("title").getBytes("ISO-8859-1"),"utf-8") ,
					new String( request.getParameter("f_title").getBytes("ISO-8859-1"),"utf-8"),
					list_content, 
					cn.edu.imu.flagnet.config.directory,
					new String(request.getParameter("reporter").getBytes("ISO-8859-1"),"utf-8"),
					new String(request.getParameter("typer").getBytes("ISO-8859-1"),"utf-8"),
					df.format(new Date()),
					request.getParameter("template"))){
				request.setAttribute("msg","<center><h2>发布成功,新文章地址<a href='article?article_id="+getNewArticleId()+"'>"+new String(request.getParameter("title").getBytes("ISO-8859-1"),"utf-8")+"</a></h2></center>");
				getServletContext().getRequestDispatcher("/result.jsp").forward(
		                request, response);
			}else{
				request.setAttribute("msg","<center><h2>发布失败</h2></center>");
				getServletContext().getRequestDispatcher("/result.jsp").forward(
		                request, response);
			}
		}
	}
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		getServletContext().getRequestDispatcher("/index.jsp").forward(
                request, response);
	}
	
	/**
	 * 功能：将文章信息存入数据库
	 * 函数：uploadArticle(topic_id,column_id,title,f_title,list_content,list_picture,reporter,typer,time)
	 * 参数：topic_id 专题编号
	 * 参数：column_id 栏目编号
	 * 参数：title 主标题
	 * 参数：f_title 副标题
	 * 参数：list_content 文章内容
	 * 参数：list_picture 图片列表
	 * 参数：reporter 记者
	 * 参数：typer 编辑
	 * 参数：time 发布时间
	 * 返回：true 成功
	 * 返回：false 失败
	 */
	public static boolean uploadArticle(String topic_id,String column_id,String title,String f_title,HashMap<String,String> list_content,String dir_picture,String reporter,String typer,String time,String template){
		
		String article_id = null;
		String content = "";
		boolean out = false;
		
		Connection conn = DBHelper.sql_connection();
		PreparedStatement pst;
		
		pst = DBHelper.pst(conn, "select max(article_id) from article");
		try {
			ResultSet ret = pst.executeQuery();
			while(ret.next()){
				article_id = ret.getString("max(article_id)");
			}
			ret.close();
			out = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out = false;
		}
		
		if((article_id+"").equals(null+"")){
			article_id = "0";
		}
		
		if(out){
			article_id = Integer.parseInt(article_id)+1+"";
			
			for(int i = 0;i<list_content.size();i++)
				content += list_content.get("value_"+i)+"	";
				content += "content_end";
					
			pst = DBHelper.pst(conn, "insert into article values("+Integer.parseInt(article_id)+","+column_id+","+topic_id+",'"+title+"','"+f_title+"','"+content+"','"+dir_picture+"','"+reporter+"','"+typer+"','"+time+"','"+template+"')");
			try {
				pst.executeUpdate();
				DBHelper.close(conn, pst);
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DBHelper.close(conn, pst);
				return false;
			}
		}else{
			DBHelper.close(conn, pst);
			return false;
		}

	}
	
	public static String getColumnId(){
		String out = "";
		
		Connection conn = DBHelper.sql_connection();
		PreparedStatement pst = DBHelper.pst(conn, "select * from column_id");
		
		try {
			ResultSet ret = pst.executeQuery();
			while(ret.next()){
				out += "<option value='"+ret.getString("column_id")+"'>"+ret.getString("name")+"</option>";
			}
			ret.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			out = "<option>服务器错误</option>";
			e.printStackTrace();
		}
		DBHelper.close(conn, pst);
		return out;
	}
	
	public static String getTopicId(){
		String out = "";
		
		Connection conn = DBHelper.sql_connection();
		PreparedStatement pst = DBHelper.pst(conn, "select * from topic_id");
		
		try {
			ResultSet ret = pst.executeQuery();
			while(ret.next()){
				out += "<option value='"+ret.getString("topic_id")+"'>"+ret.getString("name")+"</option>";
			}
			ret.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			out = "<option>服务器错误</option>";
			e.printStackTrace();
		}
		DBHelper.close(conn, pst);
		return out;
	}
	
	public static String list_templates(String path){
		File files = new File(path);
		File ret[] = files.listFiles();
		String list_files = "";
		for(File temp:ret){
			if(temp.isFile() && temp.getName().endsWith(".jsp"))
			list_files += "<option value='"+temp.getName().replace(".jsp", "")+"'>"+temp.getName().replace(".jsp", "")+"</option>";
		}
		return list_files;
	}
	
	public static String getNewArticleId(){
		
		String article_id = null;
	
		Connection conn = DBHelper.sql_connection();
		PreparedStatement pst;
		
		pst = DBHelper.pst(conn, "select max(article_id) from article");
		try {
			ResultSet ret = pst.executeQuery();
			while(ret.next()){
				article_id = ret.getString("max(article_id)");
			}
			ret.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if((article_id+"").equals(null+"")){
			article_id = "0";
		}
		DBHelper.close(conn, pst);
		return article_id;
	}
	
}
