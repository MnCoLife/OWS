/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addTopicServlet")
public class addTopicServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String realpath_addTopic_lock = Thread.currentThread().getContextClassLoader().getResource("").toString()  
				.replace("/", System.getProperty("file.separator"))
			   	 .replace("file:", "")
			   	 .replace("classes"+System.getProperty("file.separator"), "")
			   	 .substring(1)
			   	 + "addTopic.lock";
		if(File.separator.equals("/")){
			realpath_addTopic_lock = "/" + realpath_addTopic_lock;
		}
		File file_addTopic_lock = new File(realpath_addTopic_lock);
		if(file_addTopic_lock.exists()){
			request.setAttribute("error", "抱歉，你已经添加了专题，继续添加请解除锁定。");
			getServletContext().getRequestDispatcher("/error.jsp").forward(
	                request, response);
		}else{
			Connection conn = DBHelper.sql_connection();
			PreparedStatement pst = null;
			String[] names = request.getParameterValues("topic_name");
			for(String name:names){
				pst = DBHelper.pst(conn, "INSERT INTO topic_id VALUES(NULL,'"+new String(name.getBytes("ISO-8859-1"),"utf-8")+"')");
				try {
					pst.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			file_addTopic_lock.createNewFile();
			DBHelper.close(conn, pst);
			request.setAttribute("msg", "添加完成。");
			getServletContext().getRequestDispatcher("/result.jsp").forward(
	                request, response);
		}
		
		
		
	}
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		getServletContext().getRequestDispatcher("/index.jsp").forward(
                request, response);
	}

}