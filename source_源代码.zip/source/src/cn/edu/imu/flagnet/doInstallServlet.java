/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* Designed by HE Xiaoqi
 * QQ:1727832520
 */
package cn.edu.imu.flagnet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/doInstallServlet")
public class doInstallServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String realpath_install_lock = (File.separator.equals("/")?"/":"") + Thread.currentThread().getContextClassLoader().getResource("").toString()  
				 .replace("/", System.getProperty("file.separator"))
			   	 .replace("file:", "")
			   	 .replace("classes"+System.getProperty("file.separator"), "")
			   	 .substring(1)
			   	 + "install.lock";
				File file_install_lock = new File(realpath_install_lock);
				if(file_install_lock.exists()){
					request.setAttribute("error", "抱歉，你已经安装过了，重新安装请删除WEB-INF目录下的install.lock文件。");
					getServletContext().getRequestDispatcher("/error.jsp").forward(
			                request, response);
				}else{
					String text="organize_name="+Des.strEnc(new String(request.getParameter("organize_name").getBytes("ISO-8859-1"),"utf-8"), "he", "xiao", "qi")+"\r\n"+
							"copyright="+Des.strEnc(new String(request.getParameter("copyright").getBytes("ISO-8859-1"),"utf-8"), "he", "xiao", "qi")+"\r\n"+
							"isShowCopyRight="+request.getParameter("isShowCopyRight")+"\r\n"+
							"upload_directory="+request.getParameter("upload_directory")+"\r\n"+
							"app_dir="+request.getParameter("app_dir")+"\r\n"+
							"firstKey="+request.getParameter("firstKey")+"\r\n"+
							"secondKey="+request.getParameter("secondKey")+"\r\n"+
							"thirdKey="+request.getParameter("thirdKey")+"\r\n"+
							"mysql_host="+request.getParameter("mysql_host")+"\r\n"+
							"mysql_user="+request.getParameter("mysql_user")+"\r\n"+
							"mysql_password="+request.getParameter("mysql_password")+"\r\n"+
							"mysql_database="+request.getParameter("mysql_database");
					String realpath_1 = (File.separator.equals("/")?"/":"") + Thread.currentThread().getContextClassLoader().getResource("").toString()  
							.replace("/", System.getProperty("file.separator"))
						   	 .replace("file:", "")
						   	 .replace("classes"+System.getProperty("file.separator"), "")
				   	 .substring(1)
				   	 + "config.properties";
					File file_realpath_1 = new File(realpath_1);
					if(file_realpath_1.exists()){
						file_realpath_1.delete();
						file_realpath_1.createNewFile();
					}else{
						file_realpath_1.createNewFile();
					}
					FileWriter fw = new FileWriter(file_realpath_1);
					fw.flush();
					fw.write(text);
					fw.flush();
					fw.close();
					
					String realpath_2 = (File.separator.equals("/")?"/":"") + Thread.currentThread().getContextClassLoader().getResource("").toString()  
							.replace("/", System.getProperty("file.separator"))
						   	 .replace("file:", "")
						   	 .replace("classes"+System.getProperty("file.separator"), "")
				   	 .substring(1)
				   	 + "mysql.sql";
					List<String> sqlList = loadSql(realpath_2);
					String url = "jdbc:mysql://"+request.getParameter("mysql_host")+"/"+request.getParameter("mysql_database")+"?characterEncoding=utf-8";
					Connection conn = DBHelper.sql_connection_install(url, request.getParameter("mysql_user"), request.getParameter("mysql_password"));
					PreparedStatement pst = null;
					for(String sql:sqlList){
						pst = DBHelper.pst(conn, new String(sql.getBytes(),"utf-8"));
						try {
							pst.executeUpdate();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					DBHelper.close(conn, pst);
					
					String realpath_3 = (File.separator.equals("/")?"/":"") + Thread.currentThread().getContextClassLoader().getResource("").toString()  
							.replace("/", System.getProperty("file.separator"))
						   	 .replace("file:", "")
						   	 .replace("classes"+System.getProperty("file.separator"), "")
						   	 .substring(1)
						   	 + "install.lock";
					File file = new File(realpath_3);
					file.createNewFile();
					
					config.reLoad();
					
					String path_admin_login = (File.separator.equals("/")?"/":"") + Thread.currentThread().getContextClassLoader().getResource("").toString()  
							.replace("/", System.getProperty("file.separator"))
						   	 .replace("file:", "")
						   	 .replace("classes"+System.getProperty("file.separator"), "")
						   	 .replace("WEB-INF"+System.getProperty("file.separator"), "")
						   	 .substring(1)
						   	 +"admin.html";
							String app_dir = config.app_dir.equals("/")?"":config.app_dir;
							String str = "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\"><title>admin</title><style type=\"text/css\">html,body{width: 100%;height: 100%;}</style></head><body>";
								str += "<iframe scrolling=\"no\" frameborder=\"false\" allowtransparency=\"true\" style=\"border: medium none;width: 100%;height: 100%;\" src=\"";
								str += request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + app_dir + "/admin";
								str += "\"></iframe></body></html>";
							str = "<script>document.write(unescape(\""+createCertServlet.escape(str)+"\"));</script>";
							File file_admin_login = new File(path_admin_login);
							if(file_admin_login.exists()){
								file_admin_login.delete();
								file_admin_login.createNewFile();
							}else{
								file_admin_login.createNewFile();
							}
							FileWriter fw_html_login = new FileWriter(file_admin_login);
							fw_html_login.flush();
							fw_html_login.write(str);
							fw_html_login.flush();
							fw_html_login.close();
					request.setAttribute("msg", "安装完成。");
					getServletContext().getRequestDispatcher("/result.jsp").forward(
			                request, response);
				}
				
	}	
				
		private List<String> loadSql(String sqlFile) {  
	        List<String> sqlList = new ArrayList<String>();  
	  
	        try {  
	            InputStream sqlFileIn = new FileInputStream(sqlFile);  
	  
	            StringBuffer sqlSb = new StringBuffer();  
	            byte[] buff = new byte[1024];  
	            int byteRead = 0;  
	            while ((byteRead = sqlFileIn.read(buff)) != -1) {  
	                sqlSb.append(new String(buff, 0, byteRead));  
	            }  
	  
	            String[] sqlArr = sqlSb.toString().split("(;\\s*\\r\\n)|(;\\s*\\n)");  
	            for (int i = 0; i < sqlArr.length; i++) {  
	                String sql = sqlArr[i].replaceAll("--.*", "").trim();  
	                if (!sql.equals("")) {  
	                    sqlList.add(sql);  
	                }  
	            }  
	            sqlFileIn.close();
	            return sqlList;  
	        } catch (Exception ex) {  
	            ex.printStackTrace(); 
	            return null;
	        }  
					
	    }   
		
		protected void doGet(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			getServletContext().getRequestDispatcher("/index.jsp").forward(
	                request, response);
		}
	
	
}