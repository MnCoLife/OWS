/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 5.1.62-community : Database - flagnet
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*CREATE DATABASE IF NOT EXISTS `flagnet` DEFAULT CHARACTER SET utf8;*/

USE `flagnet`;

/*Table structure for table `article` */

DROP TABLE IF EXISTS `article`;

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `column_id` int(11) NOT NULL COMMENT '栏目ID',
  `topic_id` int(11) NOT NULL COMMENT '专题ID',
  `title` text NOT NULL COMMENT '标题',
  `f_title` text NOT NULL COMMENT '副标题',
  `list_content` text NOT NULL COMMENT '内容列表',
  `dir_picture` text NOT NULL COMMENT '图片目录',
  `reporter` text NOT NULL COMMENT '记者',
  `typer` text NOT NULL COMMENT '编辑',
  `time` text NOT NULL COMMENT '发布时间',
  `template` text NOT NULL COMMENT '模板',
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `article_id` (`article_id`),
  UNIQUE KEY `article_id_2` (`article_id`),
  UNIQUE KEY `article_id_3` (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='旗帜网文章';

/*Table structure for table `bm_config` */

DROP TABLE IF EXISTS `bm_config`;

CREATE TABLE `bm_config` (
  `bm_column_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '报名问题序列id',
  `question` text NOT NULL COMMENT '报名问题',
  `fee` text NOT NULL COMMENT '报名费',
  PRIMARY KEY (`bm_column_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

/*Table structure for table `bm_list` */

DROP TABLE IF EXISTS `bm_list`;

CREATE TABLE `bm_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '报名号',
  `bm_infos` text NOT NULL COMMENT '报名信息',
  `isFee` text NOT NULL COMMENT '缴费状态',
  `bmb_id` text NOT NULL COMMENT '报名表id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

/*Table structure for table `column_id` */

DROP TABLE IF EXISTS `column_id`;

CREATE TABLE `column_id` (
  `column_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '栏目id',
  `name` text NOT NULL COMMENT '栏目名称',
  PRIMARY KEY (`column_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='栏目';

/*Table structure for table `topic_id` */

DROP TABLE IF EXISTS `topic_id`;

CREATE TABLE `topic_id` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '专题id',
  `name` text NOT NULL COMMENT '专题名称',
  PRIMARY KEY (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `typer` */

DROP TABLE IF EXISTS `typer`;

CREATE TABLE `typer` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '发布者id',
  `name` text NOT NULL COMMENT '姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
